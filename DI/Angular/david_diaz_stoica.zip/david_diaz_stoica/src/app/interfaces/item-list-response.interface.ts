export interface ItemListResponse {
  count: 2223;
  next: 'https://pokeapi.co/api/v2/item/?offset=20&limit=20';
  previous: null;
  results: [
    {
      name: 'master-ball';
      url: 'https://pokeapi.co/api/v2/item/1/';
    },
    {
      name: 'ultra-ball';
      url: 'https://pokeapi.co/api/v2/item/2/';
    },
    {
      name: 'great-ball';
      url: 'https://pokeapi.co/api/v2/item/3/';
    },
    {
      name: 'poke-ball';
      url: 'https://pokeapi.co/api/v2/item/4/';
    },
    {
      name: 'safari-ball';
      url: 'https://pokeapi.co/api/v2/item/5/';
    },
    {
      name: 'net-ball';
      url: 'https://pokeapi.co/api/v2/item/6/';
    },
    {
      name: 'dive-ball';
      url: 'https://pokeapi.co/api/v2/item/7/';
    },
    {
      name: 'nest-ball';
      url: 'https://pokeapi.co/api/v2/item/8/';
    },
    {
      name: 'repeat-ball';
      url: 'https://pokeapi.co/api/v2/item/9/';
    },
    {
      name: 'timer-ball';
      url: 'https://pokeapi.co/api/v2/item/10/';
    },
    {
      name: 'luxury-ball';
      url: 'https://pokeapi.co/api/v2/item/11/';
    },
    {
      name: 'premier-ball';
      url: 'https://pokeapi.co/api/v2/item/12/';
    },
    {
      name: 'dusk-ball';
      url: 'https://pokeapi.co/api/v2/item/13/';
    },
    {
      name: 'heal-ball';
      url: 'https://pokeapi.co/api/v2/item/14/';
    },
    {
      name: 'quick-ball';
      url: 'https://pokeapi.co/api/v2/item/15/';
    },
    {
      name: 'cherish-ball';
      url: 'https://pokeapi.co/api/v2/item/16/';
    },
    {
      name: 'potion';
      url: 'https://pokeapi.co/api/v2/item/17/';
    },
    {
      name: 'antidote';
      url: 'https://pokeapi.co/api/v2/item/18/';
    },
    {
      name: 'burn-heal';
      url: 'https://pokeapi.co/api/v2/item/19/';
    },
    {
      name: 'ice-heal';
      url: 'https://pokeapi.co/api/v2/item/20/';
    },
  ];
}
