import { a as NgbSlideEventDirection, i as NgbSlide, n as NgbCarouselConfig, o as NgbSlideEventSource, r as NgbCarouselModule, t as NgbCarousel } from "./ng-bootstrap-ng-bootstrap-carousel-2OjxNzb5.js";
export { NgbCarousel, NgbCarouselConfig, NgbCarouselModule, NgbSlide, NgbSlideEventDirection, NgbSlideEventSource };
