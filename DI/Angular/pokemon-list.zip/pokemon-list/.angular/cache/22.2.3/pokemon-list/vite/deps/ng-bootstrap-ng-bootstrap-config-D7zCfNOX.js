import { Wi as setClassMetadata, dr as Service, so as ɵɵdefineService } from "./core-DwcU5Din.js";
//#region node_modules/@ng-bootstrap/ng-bootstrap/fesm2022/ng-bootstrap-ng-bootstrap-config.mjs
/**
* Global ng-bootstrap config
*
* @since 8.0.0
*/
var NgbConfig = class NgbConfig {
	constructor() {
		this.animation = true;
	}
	static {
		this.ɵfac = function NgbConfig_Factory(__ngFactoryType__) {
			return new (__ngFactoryType__ || NgbConfig)();
		};
	}
	static {
		this.ɵprov = /*@__PURE__*/ ɵɵdefineService({
			token: NgbConfig,
			factory: NgbConfig.ɵfac
		});
	}
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NgbConfig, [{ type: Service }], null, null);
})();
//#endregion
export { NgbConfig as t };
